package com.scpc.deliveryagent.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.scpc.deliveryagent.core.AsprEngine
import com.scpc.deliveryagent.core.CommitState
import com.scpc.deliveryagent.core.DraftField
import com.scpc.deliveryagent.core.FieldStatus
import com.scpc.deliveryagent.core.ProductionState
import com.scpc.deliveryagent.core.StepOutcome
import com.scpc.deliveryagent.delivery.DraftPricing
import com.scpc.deliveryagent.delivery.CatalogEvent
import com.scpc.deliveryagent.delivery.LineTokens
import com.scpc.deliveryagent.delivery.Particles
import com.scpc.deliveryagent.delivery.PreferenceScopeLevel
import com.scpc.deliveryagent.delivery.PreferenceScopes
import com.scpc.deliveryagent.delivery.displayValue
import com.scpc.deliveryagent.delivery.statusLine
import com.scpc.deliveryagent.delivery.ProductSurface
import com.scpc.deliveryagent.delivery.RatingValue
import com.scpc.deliveryagent.delivery.Recommender
import com.scpc.deliveryagent.delivery.ReviewCandidate
import com.scpc.deliveryagent.delivery.RestaurantDefinition
import com.scpc.deliveryagent.delivery.SlotDefinition
import com.scpc.deliveryagent.delivery.SlotKind
import com.scpc.deliveryagent.delivery.Slots
import com.scpc.deliveryagent.delivery.SyntheticCatalog
import com.scpc.deliveryagent.delivery.ValueScope
import com.scpc.deliveryagent.delivery.provenanceLabel
import com.scpc.deliveryagent.delivery.userLabel

import com.scpc.deliveryagent.platform.Arm
import com.scpc.deliveryagent.platform.ConversationStore
import com.scpc.deliveryagent.platform.Production
import org.json.JSONArray
import org.json.JSONObject

/**
 * Today's order.
 *
 * The user types what they want. What the app understood becomes a structured
 * draft, and what it did not becomes a question with the answers offered as taps.
 * The draft is the single source of truth: every row shows its value, its
 * synthetic amount, where the value came from and whether it still needs the
 * user. Every action goes through the same production core the Probe path uses.
 *
 * All restaurants, menus, prices, stock and orders are synthetic and local. No
 * real order, payment, account or contact is involved.
 */
class MainActivity : Activity() {

    private data class ChatLine(val speaker: String, val text: String)

    private lateinit var content: LinearLayout

    private val chat = mutableListOf<ChatLine>()
    private var openQuestions = listOf<String>()
    private var candidates = listOf<Recommender.Candidate>()

    /** One option value remembered because its slot held nothing yet. */
    private data class StoredOnFirstUse(val slot: SlotDefinition, val valueToken: String)

    /** Just remembered for later orders, and still one tap from being narrowed. */
    private var firstStored = listOf<StoredOnFirstUse>()

    /** Chosen against something already remembered; waiting on how far it reaches. */
    private var scopeChanges = listOf<ProductSurface.ScopeChange>()

    /** 식당·메뉴 proposed for sentences typed before an order exists. */
    private var discoveries = listOf<Recommender.Discovery>()
    private var exploreConditions = Recommender.Conditions.NONE
    private val exploreSentences = mutableListOf<String>()
    /**
     * The recorded order this conversation can still rate, and the last one seen.
     *
     * A review names a restaurant and a menu, so it has to belong to the order it
     * is about. Keeping the card alive on nothing but "some order exists" meant
     * that after moving on to the next restaurant it was still on screen, ready to
     * file a review of the previous meal against the new one.
     */
    private var reviewableActionId: String? = null
    private var lastSeenActionId: String? = null

    /** The user asked for the restaurant list from the menu, mid-conversation. */
    private var offeringNextOrder = false

    /** A new order has been opened and is waiting for what the user wants. */
    private var startingNewOrder = false

    /** Which arm's thread is currently in memory, and what was last written. */
    private var loadedArm = Arm.FULL
    private var persistedSignature = ""

    private var reviewRating: RatingValue? = null
    private var reviewOffers = listOf<ReviewCandidate>()
    private var reviewId: String? = null
    private var reviewNeedsTarget = false
    private var reviewTargetToken: String? = null
    private var lastDecision = "-"
    private var showDiagnostics = false

    /** Which panel covers the thread, if any. */
    private enum class Panel { DRAFT, MENU, NETWORK }

    private var panel: Panel? = null

    /** The draft row whose value chips are currently open, if any. */
    private var editingFieldId: String? = null

    private lateinit var scroller: ScrollView
    private lateinit var root: FrameLayout
    private lateinit var panelHost: FrameLayout
    private lateinit var barHost: LinearLayout
    private lateinit var appBarHost: FrameLayout

    private val catalog: SyntheticCatalog get() = Production.catalog(this)
    private val pricing: DraftPricing get() = DraftPricing(catalog)
    private val surface: ProductSurface get() = Production.surface(this)

    /**
     * The restaurant this conversation is ordering from.
     *
     * Null while a new order is being opened, even though the core still holds the
     * finished one's target: nothing has been decided yet, and the screen is back
     * at the point where the user says what they want and the app answers with
     * 식당·메뉴. Every part of the screen already keys off this, so the whole run
     * returns to its opening state from here.
     */
    private fun currentRestaurant(): RestaurantDefinition? =
        if (startingNewOrder) null else catalog.restaurant(surface.state().targetEntityId)

    /**
     * Opens an order at [restaurant] with the operation the run is actually at.
     *
     * The first order of a run resets and starts; a later one advances the session,
     * which is what expires the previous order's one-off conditions while leaving
     * stored preferences, permissions and reviews standing.
     */
    private fun beginOrder(
        surface: ProductSurface,
        restaurant: RestaurantDefinition,
    ): StepOutcome {
        val state = surface.state()
        return if (state.actions.isEmpty() && state.targetEntityId == null) {
            surface.startNewOrder(restaurant)
        } else {
            surface.nextOrderSession(restaurant)
        }
    }

    /**
     * Screen-kept working state belongs to one order conversation. A new
     * session must not inherit candidates, open scope questions or a half
     * answered review from the previous one; the stored memory itself lives
     * in the core and is untouched here.
     */
    private fun clearTransientScreenState() {
        candidates = emptyList()
        discoveries = emptyList()
        exploreConditions = Recommender.Conditions.NONE
        exploreSentences.clear()
        firstStored = emptyList()
        scopeChanges = emptyList()
        reviewableActionId = null
        offeringNextOrder = false
        startingNewOrder = false
        editingFieldId = null
        reviewRating = null
        reviewOffers = emptyList()
        reviewId = null
        reviewNeedsTarget = false
        reviewTargetToken = null
    }

    /**
     * A messenger's frame: a header that says where the order stands, a thread
     * that scrolls, the order summary and the message field pinned at the
     * bottom, and one layer above all of it for whatever panel is open.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = Ui.column(this).apply {
            // A short conversation belongs next to the message field, just as a
            // messenger does. Once the thread is taller than the viewport the
            // column wraps its children normally and the ScrollView takes over.
            gravity = Gravity.BOTTOM
            setPadding(Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 12))
        }
        scroller = Ui.scroller(this, content)
        barHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val inputBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.WHITE)
            setPadding(
                Ui.dp(this@MainActivity, 10),
                Ui.dp(this@MainActivity, 8),
                Ui.dp(this@MainActivity, 10),
                Ui.dp(this@MainActivity, 10),
            )
            addView(
                Ui.inputRow(
                    context = this@MainActivity,
                    hint = "메시지 입력",
                    sendLabel = "보내기",
                    onSend = ::onSend,
                ),
            )
        }

        appBarHost = FrameLayout(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.parseColor(Ui.CHAT_BG))
            addView(appBarHost)
            addView(
                scroller,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f),
            )
            addView(barHost)
            addView(inputBar)
        }

        panelHost = FrameLayout(this)
        root = FrameLayout(this).apply {
            addView(
                column,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ),
            )
            addView(
                panelHost,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                ),
            )
        }
        setContentView(root)
        restoreConversation()
        render()
    }

    /**
     * The thread, written back whenever it changed.
     *
     * Only on change: the write is a synchronous commit, because `이 process 종료`
     * kills the process and an asynchronous one may never land, and a redraw
     * happens far more often than a new message does.
     */
    private fun persistConversation() {
        val signature = "${chat.size}:$reviewableActionId:$lastSeenActionId:$startingNewOrder"
        if (signature == persistedSignature) return
        persistedSignature = signature
        val lines = JSONArray()
        chat.takeLast(MAX_CHAT_LINES).forEach { line ->
            lines.put(JSONObject().put("speaker", line.speaker).put("text", line.text))
        }
        ConversationStore(this, loadedArm).save(
            JSONObject()
                .put("lines", lines)
                .put("reviewableActionId", reviewableActionId ?: JSONObject.NULL)
                .put("lastSeenActionId", lastSeenActionId ?: JSONObject.NULL)
                // Kept so a relaunch in the middle of choosing a new order does not
                // drop the user back into the finished one.
                .put("startingNewOrder", startingNewOrder)
                .toString(),
        )
    }

    /**
     * Reads the thread back, for a relaunch or a switch between arms.
     *
     * A malformed record is dropped rather than crashed on: the conversation is
     * a convenience, and losing it must never cost the user the order.
     */
    private fun restoreConversation() {
        loadedArm = Production.selectedArm(this)
        chat.clear()
        reviewableActionId = null
        lastSeenActionId = null
        startingNewOrder = false
        persistedSignature = ""
        val encoded = ConversationStore(this, loadedArm).load() ?: return
        try {
            val root = JSONObject(encoded)
            val lines = root.optJSONArray("lines") ?: JSONArray()
            (0 until lines.length()).forEach { index ->
                val line = lines.getJSONObject(index)
                chat += ChatLine(line.optString("speaker"), line.optString("text"))
            }
            reviewableActionId = root.optNullableString("reviewableActionId")
            // Restored too, so a relaunch does not mistake the last recorded order
            // for a new one and reopen a rating card the user already moved past.
            lastSeenActionId = root.optNullableString("lastSeenActionId")
            startingNewOrder = root.optBoolean("startingNewOrder", false)
            // What is on disk is what was just read, so the next redraw has nothing
            // to write back.
            persistedSignature =
                "${chat.size}:$reviewableActionId:$lastSeenActionId:$startingNewOrder"
        } catch (error: Exception) {
            chat.clear()
            persistedSignature = ""
        }
    }

    private fun JSONObject.optNullableString(key: String): String? =
        if (!has(key) || isNull(key)) null else getString(key)

    private fun appBar(): View = Ui.appBar(
        context = this,
        title = currentRestaurant()?.name ?: "오늘의 주문",
        subtitle = if (currentRestaurant() == null) {
            "합성 데이터 · 실제 결제 없음"
        } else {
            // The device's own connection is named only when it is not simply
            // connected, so the header stays short in the ordinary case and the
            // line appears exactly when a judge would otherwise wonder why
            // pulling the network changed nothing.
            val link = readDeviceLink(this)
            val deviceNote = if (link.isConnected) "" else " · 기기 ${link.label}"
            "배달지 ${catalog.deliveryAlias} · 합성 ${surface.state().network.name}$deviceNote"
        },
        menuLabel = "메뉴 열기",
        onMenu = { openPanel(Panel.MENU) },
    )

    private fun openPanel(next: Panel) {
        panel = next
        editingFieldId = null
        render()
    }

    private fun closePanel() {
        panel = null
        editingFieldId = null
        render()
    }

    /** The panel is the frontmost thing on screen, so back closes it first. */
    override fun onBackPressed() {
        if (panel != null) closePanel() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        // The stored thread is the authority on return, not what is in memory.
        // Another screen may have switched arms — the two keep separate storage and
        // separate evidence, so one arm's conversation over the other's state would
        // be a false transcript — or reset everything, in which case a thread still
        // held here would be written straight back out.
        if (Production.selectedArm(this) != loadedArm) clearTransientScreenState()
        restoreConversation()
        render()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == EvaluationNotification.PERMISSION_REQUEST_CODE) render()
    }

    // ----------------------------------------------------------------- chat

    private fun onSend(message: String) {
        chat += ChatLine("나:", message)
        val restaurant = currentRestaurant()
        if (restaurant == null) {
            exploreBeforeOrdering(message)
            return
        }
        applySentence(restaurant, message)
        render()
    }

    /**
     * A sentence typed before any restaurant is chosen.
     *
     * The greeting invites exactly this — "먹고 싶은 것을 바로 말씀하셔도 됩니다" — and the
     * declared long-horizon goal answers it with 식당·메뉴 candidates. Refusing until
     * a restaurant had been picked discarded what the user said and made them say
     * it a second time.
     *
     * Nothing is committed here: `explore` reads and ranks without reaching the
     * core. Conditions accumulate, so a second sentence narrows the same list, and
     * only tapping a card starts an order.
     */
    private fun exploreBeforeOrdering(message: String) {
        val exploration = try {
            surface.explore(message)
        } catch (error: Exception) {
            chat += ChatLine("에이전트:", "처리하지 못했습니다: ${error.message}")
            render()
            return
        }
        exploreSentences += message
        exploreConditions += exploration.conditions
        discoveries = surface.exploreWith(exploreConditions)

        exploration.utterance.questions.forEach { chat += ChatLine("에이전트:", it.question) }
        if (exploration.conditions == Recommender.Conditions.NONE &&
            exploration.utterance.unrecognised.isNotEmpty()
        ) {
            // Saying only that it failed leaves the user guessing at the vocabulary.
            // The examples are the app's own — the same phrases the guide types.
            chat += ChatLine(
                "에이전트:",
                "'" + exploration.utterance.unrecognised.joinToString(" ") +
                    "'는 이해하지 못했습니다. 이렇게 말씀하시면 알아듣습니다:\n" +
                    "· 금액 — 1만5천원 이하로 / 20000원까지\n" +
                    "· 시간 — 30분 안에\n" +
                    "· 음식 종류 — 마라 / 분식 / 국수 / 튀김\n" +
                    "· 메뉴 이름 — 마라탕 / 떡볶이 / 김밥\n" +
                    "· 성격 — 따뜻한 국물 / 매운 음식 / 순한 거\n" +
                    "· 인원 — 혼자 / 2인분\n" +
                    "아래에서 식당을 직접 고르셔도 됩니다.",
            )
        }
        chat += ChatLine(
            "에이전트:",
            if (discoveries.isEmpty()) {
                "지금 조건에 맞는 메뉴가 없습니다. 아래에서 식당을 직접 고르셔도 됩니다."
            } else {
                "조건에 맞는 식당과 메뉴입니다. 하나를 고르면 그 식당에서 주문이 시작됩니다."
            },
        )
        render()
    }

    /** Applies one sentence to the order that already exists. */
    private fun applySentence(restaurant: RestaurantDefinition, message: String) {
        val turn = try {
            surface.say(restaurant, message)
        } catch (error: Exception) {
            chat += ChatLine("에이전트:", "처리하지 못했습니다: ${error.message}")
            render()
            return
        }

        val remembered = turn.firstStored.map { it.valueToken }.toSet()
        turn.applied.forEach { value ->
            val slot = catalog.slot(value.scopeToken)
            val scope = when {
                value.scope == ValueScope.REMEMBER_FOR_REUSE -> "앞으로도 기억"
                value.scope == ValueScope.THIS_ORDER_ONLY -> "이번 주문만"
                // The sentence said nothing about reuse, and the app remembered it
                // because the slot was empty. Saying which of the two happened is
                // the whole point of the line.
                value.valueToken in remembered -> "앞으로도 기억"
                else -> "이번 주문"
            }
            chat += ChatLine(
                "에이전트:",
                "${Particles.withObj(slot.label)} " +
                    "${Particles.withInto(catalog.valueLabel(value.valueToken))} 반영했습니다 ($scope).",
            )
        }
        turn.questions.forEach { chat += ChatLine("에이전트:", it) }
        turn.decision?.let { outcome ->
            lastDecision = describe(outcome)
            chat += ChatLine("에이전트:", decisionSentence(outcome))
        }
        if (turn.applied.isEmpty() && turn.questions.isEmpty() && turn.decision == null) {
            chat += ChatLine("에이전트:", "무엇을 바꿔야 할지 알아듣지 못했습니다.")
        }

        firstStored = turn.firstStored.map {
            StoredOnFirstUse(catalog.slot(it.scopeToken), it.valueToken)
        }
        scopeChanges = turn.scopeChanges
        candidates = turn.recommendations
    }

    /** Answers one open question by tapping a value the current menu offers. */
    private fun answerField(field: DraftField, valueToken: String) {
        val restaurant = currentRestaurant() ?: return
        val parsed = LineTokens.parseSlotId(field.slotId)
        val baseSlot = if (parsed == null) {
            catalog.slotOfFieldSlotId(field.slotId)
        } else {
            catalog.slot(parsed.baseScopeToken)
        }
        if (baseSlot == null) return
        // The tap goes into the transcript before the redraw so the screen the
        // user sees next already carries what they just did.
        chat += ChatLine(
            "나:",
            "${catalog.slotLabel(field.slotId)}: ${catalog.valueLabel(valueToken)}",
        )

        // Which dish, and how many of it, are this order's own facts. They are
        // never preferences, so they never raise a question of reuse.
        if (parsed != null && parsed.baseScopeToken == Slots.MAIN) {
            act { it.chooseLineMenu(restaurant, parsed.lineId, valueToken) }
            return
        }
        if (parsed != null && parsed.baseScopeToken == Slots.QUANTITY) {
            act { it.setQuantity(restaurant, parsed.lineId, valueToken) }
            return
        }

        // A row of the draft names one dish, so changing it there changes that
        // dish. The value applies at once — it is what the user asked for — and
        // how long it should last is queued as a question.
        val carrying = surface.state().draftLines.count { decl ->
            decl.slots.any { it.baseSlotId == baseSlot.slotId }
        }
        if (parsed != null && carrying > 1) {
            scopeChanges += ProductSurface.ScopeChange(
                slot = baseSlot,
                valueToken = valueToken,
                stored = surface.storedPreferencesFor(baseSlot.scopeToken).firstOrNull(),
                lineId = parsed.lineId,
            )
            act { it.setLineOption(restaurant, parsed.lineId, baseSlot, valueToken) }
            return
        }

        storeChosenValue(restaurant, baseSlot, valueToken)
    }

    /**
     * Stores a value the user chose for one option slot, at the layer the
     * situation implies.
     *
     * The value always lands on this order — it is what the user asked for.
     * Nothing remembered yet: it also becomes the standing answer and the app
     * says so, because a first answer is the best evidence of what this person
     * wants and asking "다음에도 쓸까요?" before there is anything to compare it
     * with only teaches them to answer "이번 주문만". Same as what is remembered:
     * nothing further to store. Different from it: it applies to this order and
     * how long it should last is queued as a question.
     *
     * Both queues append. Changing four options in the draft and being asked
     * about only the fourth taught nothing about the other three.
     */
    private fun storeChosenValue(
        restaurant: RestaurantDefinition,
        slot: SlotDefinition,
        valueToken: String,
    ) {
        val stored = surface.storedPreferencesFor(slot.scopeToken)
        when {
            stored.isEmpty() -> {
                firstStored += StoredOnFirstUse(slot, valueToken)
                act { it.remember(restaurant, slot, valueToken, stable = true) }
            }

            stored.any { it.value == valueToken } ->
                act { it.remember(restaurant, slot, valueToken, stable = false) }

            else -> {
                scopeChanges += ProductSurface.ScopeChange(slot, valueToken, stored.first())
                act { it.remember(restaurant, slot, valueToken, stable = false) }
            }
        }
    }

    // --------------------------------------------------------------- render

    private fun render() {
        val state = surface.state()
        EvaluationNotification.sync(this, surface.pendingEvaluationRequest())
        openQuestions = AsprEngine.openConfirmationIds(state)

        // A newly recorded order is the one this conversation can rate, however it
        // was placed — the draft's button or a typed "이대로 주문".
        state.actions.values
            .filter { it.commitState == CommitState.COMMITTED }
            .maxByOrNull { it.seq }
            ?.takeIf { it.actionId != lastSeenActionId }
            ?.let {
                lastSeenActionId = it.actionId
                reviewableActionId = it.actionId
                // Placing an order is the one moment in this app that is not
                // reversible, so it is said plainly and once, in the thread, with
                // what was ordered and what it came to.
                chat += ChatLine(
                    "에이전트:",
                    buildString {
                        append("주문이 기록되었습니다.\n")
                        append(currentRestaurant()?.name ?: "")
                        surface.lines().mapNotNull { line -> line.menuValueToken }
                            .takeIf { tokens -> tokens.isNotEmpty() }
                            ?.let { tokens ->
                                append(" · ")
                                append(tokens.joinToString { token -> catalog.valueLabel(token) })
                            }
                        append("\n합계 ${pricing.formatAmount(pricing.total(state))}")
                        append("\n합성 주문입니다 — 실제 결제·배달은 일어나지 않습니다.")
                    },
                )
            }

        appBarHost.removeAllViews()
        appBarHost.addView(appBar())
        content.removeAllViews()

        // The opening prompt happened before the user's first message, so it must
        // stay above the transcript. Rendering it after the transcript put the
        // newest user bubble at the top and then scrolled to the old restaurant
        // picker at the bottom.
        renderRestaurantChoice()
        // The thread then reads forward: what was said, what the agent proposes,
        // and the one thing it is asking about right now.
        renderConversation()
        renderDiscoveries()
        renderCandidates()
        renderNextQuestion(state)
        renderReview(state)
        renderNextOrder()

        barHost.removeAllViews()
        renderOrderBar(state)

        panelHost.removeAllViews()
        when (panel) {
            Panel.DRAFT -> panelHost.addView(draftPanel(state))
            Panel.MENU -> panelHost.addView(menuPanel())
            Panel.NETWORK -> panelHost.addView(networkPanel())
            null -> Unit
        }

        persistConversation()
        scrollToBottom()
    }

    /**
     * The newest message is what the user is looking at.
     *
     * The thread is rebuilt from scratch on every redraw, and a ScrollView clamps
     * its offset to zero while the rebuilt column still has no height — so without
     * this every tap would land the user back at the oldest bubble and leave them
     * hunting for what just happened. `scrollTo` rather than `fullScroll` because
     * the latter also moves focus, which would take the caret out of the message
     * field. The second pass catches cards whose chips wrap onto another line and
     * therefore grow the column after the first one.
     */
    private fun scrollToBottom() {
        scroller.post {
            scroller.scrollTo(0, content.height)
            scroller.post { scroller.scrollTo(0, content.height) }
        }
    }

    /** Every synthetic restaurant, offered whenever no order is open yet. */
    private fun renderRestaurantChoice() {
        if (currentRestaurant() != null) return
        content.addView(
            Ui.chatLine(
                this,
                "에이전트:",
                (
                    if (startingNewOrder) {
                        "새 주문을 시작할게요. 오늘은 뭘 드시고 싶으세요?\n"
                    } else {
                        "안녕하세요. 어디서 주문할까요?\n"
                    }
                    ) +
                    "먹고 싶은 것을 바로 말씀하셔도 됩니다 — " +
                    "'매운 음식', '마라', '1만5천원 이하로 따뜻한 국물'처럼요.",
            ),
        )
        content.addView(
            Ui.agentCard(
                context = this,
                question = "식당부터 고르기",
                hint = "먼저 드시고 싶은 것을 말씀하시면 식당과 메뉴를 함께 골라 드립니다. " +
                    "6곳 모두 합성 실험 매장이고 실제 주문·결제는 일어나지 않습니다.",
                chips = catalog.restaurants.map { restaurant ->
                    Ui.Chip(label = restaurant.name) {
                        clearTransientScreenState()
                        chat += ChatLine("에이전트:", "${restaurant.name}으로 새 주문을 시작했습니다.")
                        act { beginOrder(it, restaurant) }
                    }
                },
            ),
        )
    }

    private fun renderConversation() {
        var previousSpeaker = ""
        chat.takeLast(MAX_CHAT_LINES).forEach { line ->
            content.addView(
                Ui.chatLine(this, line.speaker, line.text, showName = line.speaker != previousSpeaker),
            )
            previousSpeaker = line.speaker
        }
    }

    /**
     * One question at a time.
     *
     * The draft usually has several blanks at once, but a person answers them
     * one after another, and a card per answer keeps the thread readable and
     * leaves each choice in the transcript. The counter says how many are left
     * so the run of questions never feels open-ended.
     */
    private fun renderNextQuestion(state: ProductionState) {
        val restaurant = currentRestaurant() ?: return

        // A change to something remembered is settled before anything else: the
        // draft cannot honestly move on while it is unclear which value stands.
        val change = scopeChanges.firstOrNull()
        if (change != null) {
            val levels = surface.scopeChoicesFor(restaurant, change.slot)
            content.addView(
                Ui.agentCard(
                    context = this,
                    question = "${Particles.withObj(change.slot.label)} " +
                        "${Particles.withInto(catalog.valueLabel(change.valueToken))} " +
                        "바꿨습니다. 앞으로도 이렇게 할까요?",
                    hint = change.stored?.let {
                        "기억하고 있는 값은 ${catalog.valueLabel(it.value)}입니다 " +
                            "(${storedScopeLabel(it)})."
                    } ?: "이번 주문에는 이미 적용했습니다.",
                    chips = listOf(
                        Ui.Chip(label = "이번 주문만") { applyScopeChange(change, null) },
                    ) + levels.map { level ->
                        Ui.Chip(label = changeLevelLabel(level)) { applyScopeChange(change, level) }
                    },
                    footnote = queueNote(scopeChanges.size + firstStored.size)
                        ?: "고른 범위만 바뀌고, 나머지 범위의 기억은 그대로 둡니다.",
                ),
            )
            return
        }

        // What was just learned, settled before the next thing is asked.
        //
        // This used to sit beside the next question, so answering one option put
        // two cards on screen at once — one of them a notice the user was meant to
        // ignore. The card slot holds exactly one thing to attend to, and the run
        // reads the way it happens: 값을 고르고, 얼마나 쓸지 정하고, 다음 항목.
        val stored = firstStored.firstOrNull()
        if (stored != null) {
            content.addView(
                Ui.agentCard(
                    context = this,
                    question = "${Particles.withObj(stored.slot.label)} " +
                        "${catalog.valueLabel(stored.valueToken)}(으)로 기억했습니다.",
                    hint = "다음 주문부터 이 항목은 묻지 않고 이 값으로 채웁니다.",
                    chips = listOf(
                        Ui.Chip(label = "좋아요") {
                            firstStored = firstStored - stored
                            render()
                        },
                        Ui.Chip(label = "이번 주문만 할래요") {
                            firstStored = firstStored - stored
                            chat += ChatLine("나:", "${stored.slot.label}은 이번 주문만")
                            chat += ChatLine(
                                "에이전트:",
                                "${Particles.withObj(stored.slot.label)} 기억에서 지우고 " +
                                    "이번 주문에만 적용합니다.",
                            )
                            act {
                                it.narrowToThisOrder(restaurant, stored.slot, stored.valueToken)
                            }
                        },
                    ),
                    footnote = queueNote(scopeChanges.size + firstStored.size)
                        ?: "'내 취향과 기억'에서 언제든 고치거나 지울 수 있습니다.",
                ),
            )
            return
        }

        val total = openQuestions.size
        if (total == 0) return
        val fieldId = openQuestions.first()
        val field = state.fields[fieldId] ?: return
        val slot = catalog.slotOfFieldSlotId(field.slotId)
            ?: catalog.baseSlotOfLineSlotId(field.slotId)
            ?: return
        val chips = catalog.valuesFor(restaurant, slot.scopeToken)
            .filter { it.inStock }
            .map { option ->
                Ui.Chip(
                    label = option.label,
                    sub = if (option.priceDelta > 0) {
                        "+${pricing.formatAmount(option.priceDelta)}"
                    } else {
                        ""
                    },
                ) { answerField(field, option.token) }
            }
        if (chips.isEmpty()) return
        content.addView(
            Ui.agentCard(
                context = this,
                question = "${Particles.withObj(questionLabel(field))} 정해 주세요.",
                hint = if (total == 1) "마지막 확인입니다." else "1 / $total · 하나씩 여쭤볼게요.",
                chips = chips,
                footnote = if (slot.kind == SlotKind.MENU_OPTION &&
                    surface.storedPreferencesFor(slot.scopeToken).isEmpty()
                ) {
                    "고르신 값을 앞으로도 쓰겠습니다. 바로 아래에서 이번 주문만으로 바꿀 수 있습니다."
                } else {
                    ""
                },
            ),
        )
    }

    /** The option's own name; the line it belongs to is already in the draft. */
    private fun questionLabel(field: DraftField): String =
        catalog.baseSlotOfLineSlotId(field.slotId)?.label ?: catalog.slotLabel(field.slotId)

    /** How many more of these are waiting, when more than this one is. */
    private fun queueNote(remaining: Int): String? =
        if (remaining > 1) "이어서 정할 것 ${remaining - 1}개가 더 있습니다." else null

    /**
     * Settles how long a change already applied to this order should last.
     *
     * "이번 주문만" writes nothing further: the value is on the draft already, as a
     * one-off that expires with the session. Each wider level stores at that level
     * alone and leaves the others as they were.
     */
    private fun applyScopeChange(
        change: ProductSurface.ScopeChange,
        level: PreferenceScopeLevel?,
    ) {
        val restaurant = currentRestaurant() ?: return
        scopeChanges = scopeChanges - change
        chat += ChatLine("나:", level?.let(::changeLevelLabel) ?: "이번 주문만")
        chat += ChatLine(
            "에이전트:",
            "${Particles.withObj(change.slot.label)} " +
                if (level == null) {
                    val kept = change.stored?.let {
                        " 기억한 ${catalog.valueLabel(it.value)}은(는) 그대로 둡니다."
                    }.orEmpty()
                    "이번 주문에만 적용합니다.$kept"
                } else {
                    "${Particles.withInto(catalog.valueLabel(change.valueToken))} " +
                        "${changeLevelLabel(level)} 범위로 저장했습니다."
                },
        )
        if (level == null) {
            render()
            return
        }
        act { it.rememberAtLevel(restaurant, change.slot, change.valueToken, level) }
    }

    /** The same three scopes, named as the change they make. */
    private fun changeLevelLabel(level: PreferenceScopeLevel): String = when (level) {
        PreferenceScopeLevel.RESTAURANT_MENU_OVERRIDE -> "이 식당·이 메뉴만 앞으로도"
        PreferenceScopeLevel.MENU_TYPE -> "같은 메뉴 유형이면 앞으로도"
        PreferenceScopeLevel.GLOBAL_DEFAULT -> "항상 이걸로 바꾸기"
    }

    /** Where a stored preference currently reaches, in one phrase. */
    private fun storedScopeLabel(stored: ProductSurface.StoredPreference): String =
        when (stored.level) {
            PreferenceScopeLevel.RESTAURANT_MENU_OVERRIDE ->
                "이 식당·메뉴만: " + (stored.menuToken?.let(catalog::valueLabel) ?: "")
            PreferenceScopeLevel.MENU_TYPE ->
                "메뉴 유형: " + (stored.menuTypeToken?.let { catalog.menuType(it).label } ?: "")
            PreferenceScopeLevel.GLOBAL_DEFAULT -> "모든 메뉴"
        }

    /**
     * What the agent proposes right now.
     *
     * Until a dish is in the draft there is always something to propose, so the
     * candidates stand on their own rather than waiting for a sentence the
     * parser happened to understand. Saying more only re-ranks them: a person
     * who picks a restaurant and says nothing still sees the menu, and one whose
     * words were not understood is never left with a dead end.
     */
    /**
     * 식당·메뉴 proposed for a sentence typed before any order exists.
     *
     * Each row names its restaurant, because that is the point being made: the
     * user said what they wanted and did not have to find the restaurant first.
     * The chip card stays below as the direct route.
     */
    private fun renderDiscoveries() {
        if (currentRestaurant() != null || discoveries.isEmpty()) return
        val card = Ui.agentCard(
            context = this,
            question = "이런 식당은 어떠세요?",
            hint = "고르면 그 식당에서 주문이 시작되고, 말씀하신 조건이 그대로 반영됩니다.",
            chips = emptyList(),
        )
        discoveries.forEach { discovery ->
            val candidate = discovery.candidate
            card.addView(
                Ui.candidateRow(
                    context = this,
                    name = "${discovery.restaurant.name} · ${candidate.label}",
                    meta = buildString {
                        append(pricing.formatAmount(candidate.amount))
                        append(" · ${candidate.estimateMinutes}분")
                        if (candidate.rating.count > 0) append(" · ${candidate.rating.label()}")
                        candidate.blockedBy?.let { append(" · 제외: $it") }
                    },
                    reasons = candidate.reasons.joinToString(" · ") { "${it.badge} ${it.detail}" },
                    actionLabel = "여기서 시작",
                    onTap = if (candidate.offerable) {
                        { startOrderFrom(discovery) }
                    } else {
                        null
                    },
                ),
            )
        }
        content.addView(card)
    }

    /**
     * Starts the order the user picked out of the proposals.
     *
     * The sentences that produced the list are replayed at the chosen restaurant
     * through the ordinary `say`, so the stated conditions land against a real
     * target exactly as if they had been typed after picking. One path, not two —
     * and nothing the user said has to be said again.
     */
    private fun startOrderFrom(discovery: Recommender.Discovery) {
        val restaurant = discovery.restaurant
        val sentences = exploreSentences.toList()
        discoveries = emptyList()
        exploreConditions = Recommender.Conditions.NONE
        exploreSentences.clear()
        // The order exists from here, so the screen stops standing in for the
        // opening state and shows the draft this pick just started.
        startingNewOrder = false
        chat += ChatLine("나:", "${restaurant.name} · ${discovery.candidate.label}")
        actQuiet { surface ->
            beginOrder(surface, restaurant)
            sentences.forEach { sentence -> applySentence(restaurant, sentence) }
            surface.addLine(restaurant, discovery.candidate.valueToken)
        }
    }

    /**
     * This restaurant's menu, ordered by what the user said.
     *
     * It is a list to choose from, not a recommendation, and it stopped claiming
     * to be one: once the restaurant is settled its dishes are all of a kind, and
     * calling six near-identical options a recommendation only made the word
     * mean less. Recommending is what happens before a restaurant exists, where
     * the app answers a sentence with 식당·메뉴 pairs across every restaurant.
     */
    private fun renderCandidates() {
        val restaurant = currentRestaurant() ?: return
        if (reviewableActionId != null) return
        val shown = candidates.ifEmpty {
            if (surface.lines().isEmpty()) {
                Recommender(catalog).candidates(surface.state(), restaurant)
            } else {
                emptyList()
            }
        }
        if (shown.isEmpty()) return
        val card = Ui.agentCard(
            context = this,
            question = "${restaurant.name} 메뉴",
            hint = "말씀하신 조건과 저장된 취향에 맞춘 순서입니다. 담을 것을 고르세요.",
            chips = emptyList(),
        )
        shown.forEach { candidate ->
            card.addView(
                Ui.candidateRow(
                    context = this,
                    name = candidate.label,
                    meta = buildString {
                        append(pricing.formatAmount(candidate.amount))
                        append(" · ${candidate.estimateMinutes}분")
                        // The user's own past ratings of this exact menu. They order
                        // what conditions and preferences leave tied, never more.
                        if (candidate.rating.count > 0) append(" · ${candidate.rating.label()}")
                        candidate.blockedBy?.let { append(" · 제외: $it") }
                    },
                    reasons = candidate.reasons.joinToString(" · ") { "${it.badge} ${it.detail}" },
                    actionLabel = "담기",
                    onTap = if (candidate.offerable) {
                        {
                            chat += ChatLine("나:", "${candidate.label} 담기")
                            candidates = emptyList()
                            act { it.addLine(restaurant, candidate.valueToken) }
                        }
                    } else {
                        null
                    },
                ),
            )
        }
        content.addView(card)
    }

    /** The order summary, always within reach above the message field. */
    private fun renderOrderBar(state: ProductionState) {
        if (currentRestaurant() == null) return
        val lines = surface.lines()
        if (lines.isEmpty() && state.fields.isEmpty()) return
        val total = pricing.total(state)
        barHost.addView(
            Ui.orderBar(
                context = this,
                count = lines.size,
                summary = when {
                    // A recorded order is not a draft any more. Leaving the bar
                    // saying 주문서 left the finished order looking like one still
                    // being filled in.
                    reviewableActionId != null -> "주문 완료 · ${pricing.formatAmount(total)}"
                    openQuestions.isEmpty() -> "주문서 ${pricing.formatAmount(total)} · 확인 완료"
                    else -> "주문서 ${pricing.formatAmount(total)} · 확인 ${openQuestions.size}건 남음"
                },
                onOpen = { openPanel(Panel.DRAFT) },
            ),
        )
    }


    /**
     * Leaving a review, and deciding what of it is worth remembering.
     *
     * The section only appears once an order has been recorded, because there is
     * nothing to review before that.
     */
    private fun renderReview(state: ProductionState) {
        val restaurant = currentRestaurant() ?: return
        if (state.actions.isEmpty()) return

        // A question that has been answered stops being asked, so the card leaves
        // once the review is in — what was written afterwards lives in 내 취향과
        // 기억, not in the middle of the thread where it pushed the next order off
        // the screen.
        //
        // What keeps it open is the order, not the notice. The arrived request is a
        // passing thing by design — it expires in a few steps so it can never gate
        // the next order — and tying the card to it meant a person who took a moment
        // before rating found the way to do it had quietly closed. So the card
        // stands until the last recorded order has been reviewed, and the notice
        // only changes what the agent says above it.
        val settlingReview = reviewNeedsTarget || reviewOffers.isNotEmpty()
        val rateable = reviewableActionId
        val reviewed = rateable == null || state.reviews.any { it.actionId == rateable }
        if (reviewed && !settlingReview) return
        // Ordering straight from the draft can leave memory questions behind it —
        // the sheet covers the thread, so they were queued rather than shown. They
        // are about the order that just happened, so they come first, one at a
        // time, before the screen moves on to rating it.
        if (scopeChanges.isNotEmpty() || firstStored.isNotEmpty()) return

        val requested = surface.pendingEvaluationRequest()
        if (!reviewed) {
            content.addView(
                Ui.chatLine(
                    this,
                    "에이전트:",
                    if (requested) {
                        "식사는 어떠셨어요? 별점과 한 줄 평가를 남겨 주세요."
                    } else {
                        "주문을 기록했습니다. 드시고 나서 평가를 남겨 주세요."
                    },
                ),
            )
            val rated = reviewRating
            content.addView(
                Ui.agentCard(
                    context = this,
                    question = "지난 주문 평가",
                    hint = restaurant.name +
                        (reviewTargetToken?.let { " · " + catalog.valueLabel(it) } ?: ""),
                    chips = surface.ratingOptions().map { rating ->
                        Ui.Chip(label = rating.label, selected = rated?.token == rating.token) {
                            reviewRating = rating
                            render()
                        }
                    },
                ).also { card ->
                    card.addView(
                        Ui.inputRow(
                            context = this,
                            hint = "예: 국물은 괜찮았는데 간이 좀 셌어",
                            sendLabel = "남기기",
                            onSend = { text -> onReview(restaurant, text) },
                        ),
                    )
                },
            )
        }

        if (reviewNeedsTarget) {
            val id = reviewId
            if (id != null) {
                content.addView(
                    Ui.agentCard(
                        context = this,
                        question = "어느 메뉴에 대한 평가인가요?",
                        hint = "대상이 정해져야 평점과 취향 후보를 그 메뉴에 연결합니다.",
                        chips = surface.lines().mapNotNull { line ->
                            val menuToken = line.menuValueToken ?: return@mapNotNull null
                            Ui.Chip(label = catalog.valueLabel(menuToken)) {
                                try {
                                    reviewOffers = surface.setReviewTarget(restaurant, id, menuToken)
                                    reviewTargetToken = menuToken
                                    reviewNeedsTarget = false
                                } catch (error: Exception) {
                                    Toast.makeText(
                                        this,
                                        "처리하지 못했습니다: ${error.message}",
                                        Toast.LENGTH_LONG,
                                    ).show()
                                }
                                render()
                            }
                        },
                    ),
                )
            }
        }

        if (reviewOffers.isNotEmpty() && !reviewNeedsTarget) {
            reviewOffers.forEach { offer ->
                val slot = catalog.slot(offer.slotToken)
                val chips = surface
                    .reviewScopeChoices(restaurant, offer, reviewTargetToken)
                    .map { level ->
                        Ui.Chip(label = scopeLevelLabel(level)) { acceptReviewOffer(offer, level) }
                    } + Ui.Chip(label = "저장하지 않음") { declineReviewOffer(offer) }
                content.addView(
                    Ui.agentCard(
                        context = this,
                        question = "다음부터 ${Particles.withObj(slot.label)} " +
                            "${Particles.withInto(catalog.valueLabel(offer.impliesValue))} 해 드릴까요?",
                        hint = "'${offer.matchedText}'라고 하셔서요. 어디까지 적용할지 골라 주세요.",
                        chips = chips,
                        footnote = "고른 범위에만 저장하고, 다른 범위는 건드리지 않습니다.",
                    ),
                )
            }
        }

    }

    private fun onReview(restaurant: RestaurantDefinition, text: String) {
        val turn = try {
            surface.submitReview(restaurant, reviewRating?.token, text)
        } catch (error: Exception) {
            Toast.makeText(this, "평가를 남기지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
            return
        }
        reviewId = turn.reviewId
        reviewOffers = turn.offers
        reviewNeedsTarget = turn.needsTarget
        reviewTargetToken = turn.targetMenuToken
        // The rating belonged to the review that was just filed. Keeping it
        // selected would make the next request look half answered already.
        reviewRating = null
        chat += ChatLine("나:", text)
        turn.notes.forEach { chat += ChatLine("에이전트:", it) }
        chat += ChatLine(
            "에이전트:",
            when {
                turn.needsTarget -> "평가를 기록했습니다. 어느 메뉴에 대한 평가인지 정해 주세요."
                turn.offers.isEmpty() -> "평가를 기록했습니다. 다음 주문에 적용할 항목은 없습니다."
                else -> "평가를 기록했습니다. 다음부터 적용할지, 어느 범위에 적용할지 정해 주세요."
            },
        )
        render()
    }

    private fun scopeLevelLabel(level: PreferenceScopeLevel): String = when (level) {
        PreferenceScopeLevel.RESTAURANT_MENU_OVERRIDE -> "이 식당·이 메뉴만"
        PreferenceScopeLevel.MENU_TYPE -> "같은 메뉴 유형이면 어디서든"
        PreferenceScopeLevel.GLOBAL_DEFAULT -> "모든 메뉴"
    }

    private fun acceptReviewOffer(offer: ReviewCandidate, level: PreferenceScopeLevel) {
        val id = reviewId ?: return
        val restaurant = currentRestaurant() ?: return
        reviewOffers = reviewOffers - offer
        chat += ChatLine("나:", scopeLevelLabel(level))
        chat += ChatLine(
            "에이전트:",
            "${Particles.withObj(catalog.slot(offer.slotToken).label)} " +
                "${Particles.withInto(catalog.valueLabel(offer.impliesValue))} 저장했습니다 — " +
                "${scopeLevelLabel(level)} 범위에서 다음 초안부터 적용합니다.",
        )
        act { it.acceptFromReview(restaurant, id, offer, level) }
    }

    private fun declineReviewOffer(offer: ReviewCandidate) {
        try {
            surface.dismissFromReview(offer)
        } catch (error: Exception) {
            Toast.makeText(this, "처리하지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
        }
        // A stale offer leaves the screen either way; only the stored state
        // speaks through the toast above.
        reviewOffers = reviewOffers - offer
        chat += ChatLine("나:", "저장하지 않음")
        chat += ChatLine("에이전트:", "기억하지 않겠습니다. 평가 기록만 남습니다.")
        render()
    }

    /**
     * Starting the next order.
     *
     * Once this order is recorded the conversation moves on, which is where a
     * preference stated here first has to prove itself. Choosing the restaurant
     * opens a new session, so nothing said only for the last order carries into
     * this one.
     *
     * It belongs to the order this conversation just finished, and only to that.
     * Keyed on "any order was ever recorded" it stayed pinned under every later
     * message for the rest of the run — six restaurant chips permanently between
     * the user and their own conversation, offering to start a next order in the
     * middle of the one they were placing.
     */
    private fun renderNextOrder() {
        val finished = reviewableActionId != null
        if (!finished && !offeringNextOrder) return
        if (currentRestaurant() == null) return
        if (reviewOffers.isNotEmpty() || reviewNeedsTarget) return
        content.addView(
            Ui.agentCard(
                context = this,
                question = "다음 주문을 시작할까요?",
                hint = "새 대화가 열립니다. 드시고 싶은 것을 말씀하시면 식당과 메뉴를 함께 골라 드립니다. " +
                    "이번 주문에만 적용한 값은 따라오지 않고, 저장한 취향은 그대로 쓰입니다.",
                chips = listOf(
                    Ui.Chip(label = "새로 주문하기") {
                        // A new order is a new conversation, and it starts where the
                        // first one did — with the user saying what they want, not
                        // with a list of restaurants. Picking the restaurant first
                        // was the very thing the discovery path exists to undo, and
                        // it was still the only way in to every order after the
                        // first. Nothing reaches the core until a dish is picked, so
                        // the finished order stands until it is genuinely replaced.
                        clearTransientScreenState()
                        chat.clear()
                        startingNewOrder = true
                        render()
                    },
                ) + if (finished) {
                    emptyList()
                } else {
                    // Asked for from the menu in the middle of an order, so it has
                    // to be dismissible without abandoning that order.
                    listOf(
                        Ui.Chip(label = "아니요, 계속할게요") {
                            offeringNextOrder = false
                            render()
                        },
                    )
                },
            ),
        )
    }

    /**
     * The draft, raised over the thread.
     *
     * A person checks the order when they are about to place it, not at the
     * point in the conversation where each line happened to be added, so the
     * draft lives one tap from anywhere rather than scrolling away.
     */
    private fun draftPanel(state: ProductionState): View {
        val restaurant = currentRestaurant()
        val recorded = reviewableActionId != null
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(
                Ui.dp(this@MainActivity, 16),
                0,
                Ui.dp(this@MainActivity, 16),
                Ui.dp(this@MainActivity, 8),
            )
        }

        fun addRow(field: DraftField, label: String) {
            val entry = catalog.value(field.value)
            val amount = if (entry != null && entry.priceDelta > 0) {
                " (+${pricing.formatAmount(entry.priceDelta)})"
            } else {
                ""
            }
            // A recorded order is a receipt, not a form. Offering 변경 on it would
            // let the user edit something that has already happened.
            val choices = if (recorded) emptyList() else editChoices(field, restaurant)
            val open = editingFieldId == field.fieldId
            body.addView(
                Ui.draftRow(
                    context = this,
                    label = label,
                    value = field.displayValue(catalog, pricing, state) + amount,
                    source = field.statusLine(state),
                    needsUser = field.status != FieldStatus.CONFIRMED &&
                        field.status != FieldStatus.AUTO_APPLIED,
                    onChange = if (choices.isEmpty()) {
                        null
                    } else {
                        {
                            editingFieldId = if (open) null else field.fieldId
                            render()
                        }
                    },
                ),
            )
            if (open && choices.isNotEmpty()) {
                body.addView(
                    Ui.chipFlow(this, Ui.cardContentWidth(this), choices),
                )
            }
        }

        val renderedFieldIds = mutableSetOf<String>()
        surface.lines().forEach { line ->
            val menuLabel = line.menuValueToken?.let(catalog::valueLabel) ?: "메뉴 미정"
            val price = line.menuValueToken?.let { catalog.value(it)?.priceDelta } ?: 0
            body.addView(
                Ui.lineHeader(
                    context = this,
                    name = menuLabel,
                    price = if (price > 0) pricing.formatAmount(price) else "",
                    onRemove = if (restaurant == null) {
                        null
                    } else {
                        {
                            chat += ChatLine("나:", "$menuLabel 빼기")
                            actQuiet { it.removeLine(restaurant, line.lineId) }
                        }
                    },
                ),
            )
            line.slots.forEach slot@{ binding ->
                val field = state.fields[AsprEngine.fieldIdFor(binding.lineSlotId)] ?: return@slot
                renderedFieldIds += field.fieldId
                addRow(field, catalog.baseSlotOfLineSlotId(field.slotId)?.label ?: "옵션")
            }
        }

        state.fields.values.sortedBy { it.fieldId }.forEach { field ->
            if (field.fieldId in renderedFieldIds) return@forEach
            // A passing notice such as the rating request is not a draft row.
            val isDraftRow = field.slotId == AsprEngine.SLOT_TOTAL ||
                catalog.slotOfFieldSlotId(field.slotId) != null ||
                LineTokens.parseSlotId(field.slotId) != null
            if (!isDraftRow) return@forEach
            if (field.slotId == AsprEngine.SLOT_TOTAL) return@forEach
            addRow(field, catalog.slotLabel(field.slotId))
        }

        if (restaurant != null && !recorded && surface.lines().isNotEmpty()) {
            val sides = catalog.sideMenus(restaurant).filter { it.inStock }
            if (sides.isNotEmpty()) {
                body.addView(Ui.menuGroup(this, "사이드 추가").apply { setPadding(0, Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 4)) })
                body.addView(
                    Ui.chipFlow(
                        this,
                        Ui.cardContentWidth(this),
                        sides.map { side ->
                            Ui.Chip(
                                label = side.label,
                                sub = "+${pricing.formatAmount(side.priceDelta)}",
                            ) {
                                chat += ChatLine("나:", "사이드: ${side.label}")
                                act { it.addLine(restaurant, side.token) }
                            }
                        },
                    ),
                )
            }
        }

        val total = pricing.total(state)
        val budget = pricing.budgetLimit(state)
        val estimate = pricing.estimateMinutes(state)
        body.addView(Ui.totalRow(this, "합계", pricing.formatAmount(total)))
        body.addView(
            Ui.body(
                this,
                buildString {
                    if (budget != null) {
                        append(
                            if (total <= budget) {
                                "예산 ${pricing.formatAmount(budget)} 안"
                            } else {
                                "예산 ${pricing.formatAmount(budget)} 초과"
                            },
                        )
                    }
                    if (estimate != null) {
                        if (isNotEmpty()) append(" · ")
                        append("예상 ${estimate}분")
                    }
                    if (isNotEmpty()) append(" · ")
                    append("지금까지 확인·입력 ${state.resolutions.size}회")
                },
            ),
        )
        pricing.lines(state).filter { !it.inStock }.takeIf { it.isNotEmpty() }?.let { soldOut ->
            body.addView(
                Ui.body(this, "품절로 다시 골라야 하는 항목: " + soldOut.joinToString { it.label }),
            )
        }

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                if (recorded) {
                    // The order is placed. The only thing left to do here is leave,
                    // and a second 주문하기 button would invite a duplicate.
                    Ui.primaryAction(
                        context = this@MainActivity,
                        text = "닫기",
                        enabled = true,
                    ) { closePanel() }
                } else {
                    Ui.primaryAction(
                        context = this@MainActivity,
                        text = if (openQuestions.isEmpty()) {
                            "이대로 주문하기 · ${pricing.formatAmount(total)}"
                        } else {
                            "확인 ${openQuestions.size}건을 마치면 주문할 수 있습니다"
                        },
                        enabled = openQuestions.isEmpty() && restaurant != null,
                    ) {
                        closePanel()
                        restaurant?.let { r -> act { it.requestDecision(r) } }
                    }
                },
            )
        }
        return Ui.sheet(
            this,
            if (recorded) "완료된 주문" else "주문서",
            body,
            footer,
        ) { closePanel() }
    }

    /** Everything that is not the conversation, gathered behind one control. */
    private fun menuPanel(): View {
        val state = surface.state()
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        body.addView(Ui.menuGroup(this, "제품"))
        body.addView(
            Ui.menuItem(this, "내 취향과 기억", "저장된 것 전부 · 범위별 정정·철회·삭제") {
                closePanel()
                startActivity(Intent(this, MemoryActivity::class.java))
            },
        )
        if (state.actions.isNotEmpty()) {
            // The chips stand at the end of the thread on their own only when the
            // order they belong to has just been recorded. Between orders this is
            // the way back to them.
            body.addView(
                Ui.menuItem(this, "다른 식당에서 새로 주문", "식당 목록을 대화 끝에 엽니다") {
                    offeringNextOrder = true
                    closePanel()
                },
            )
        }

        body.addView(Ui.menuGroup(this, "합성 환경 조작 — 앱 밖에서 일어나는 일"))
        body.addView(
            Ui.menuItem(this, "시간 경과", "지연된 평가 요청이 도착합니다") {
                advanceSyntheticTime()
            },
        )
        currentRestaurant()?.let { restaurant ->
            val events = catalog.eventsFor(restaurant)
            if (events.isEmpty()) {
                body.addView(
                    Ui.menuItem(
                        this,
                        "재고·가격 변화 없음",
                        "현재 식당에는 준비된 합성 변경 이벤트가 없습니다",
                    ) {
                        Toast.makeText(
                            this,
                            "현재 식당에는 적용할 합성 재고·가격 변화가 없습니다.",
                            Toast.LENGTH_SHORT,
                        ).show()
                    },
                )
            } else {
                events.forEach { event ->
                    body.addView(
                        Ui.menuItem(this, "재고·가격 변화", event.description) {
                            applySyntheticCatalogEvent(event)
                        },
                    )
                }
            }
        }
        body.addView(
            Ui.menuItem(
                this,
                "network 상태",
                "합성 ${state.network.name} · 기기 ${readDeviceLink(this).label} · 눌러서 바꾸기",
            ) {
                openPanel(Panel.NETWORK)
            },
        )
        body.addView(
            Ui.menuItem(this, "이 process 종료", "재실행 뒤 이어지는지 확인") {
                // A real process death, not a screen that pretends. State is already
                // durably committed, so the next launch reconciles from disk.
                finishAffinity()
                android.os.Process.killProcess(android.os.Process.myPid())
            },
        )

        body.addView(Ui.menuGroup(this, "검증"))
        body.addView(
            Ui.menuItem(this, "비교 실행", "full / claim-off") {
                closePanel()
                startActivity(Intent(this, ComparisonActivity::class.java))
            },
        )
        body.addView(
            Ui.menuItem(this, "평가·내보내기", "공개 입력 불러오기 · 실행 · 결과 내보내기") {
                closePanel()
                startActivity(Intent(this, ProbeConsoleActivity::class.java))
            },
        )
        body.addView(
            Ui.menuItem(
                this,
                "검증 정보",
                buildString {
                    append("session ${state.sessionLabel.ifEmpty { "없음" }} · ")
                    append("epoch ${state.processEpoch} · ")
                    append("${armLabel()} · ")
                    append("catalog ${catalog.snapshotDigest.take(12)} · ")
                    append("마지막 판단 $lastDecision")
                },
            ) { },
        )
        if (!EvaluationNotification.hasPermission(this)) {
            body.addView(
                Ui.menuItem(this, "평가 알림 허용 요청", "거부해도 주문·기억·복구는 그대로 동작합니다") {
                    closePanel()
                    EvaluationNotification.requestPermission(this)
                },
            )
        }
        return Ui.sheet(this, "메뉴", body, null) { closePanel() }
    }

    /** Advances the synthetic clock and says what, if anything, visibly changed. */
    private fun advanceSyntheticTime() {
        panel = null
        editingFieldId = null
        val before = surface.pendingEvaluationRequest()
        val outcome = try {
            surface.advanceTime()
        } catch (error: Exception) {
            Toast.makeText(this, "처리하지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
            render()
            return
        }
        lastDecision = describe(outcome)
        val after = surface.pendingEvaluationRequest()
        chat += ChatLine(
            "에이전트:",
            when {
                !before && after -> "합성 시간이 경과해 지난 주문의 평가 요청이 도착했습니다."
                before && !after -> "합성 시간이 경과해 도착해 있던 평가 요청의 유효 시간이 지났습니다. 주문 기록은 그대로입니다."
                after -> "합성 시간이 경과했습니다. 도착해 있던 평가 요청은 그대로 확인할 수 있습니다."
                else -> "합성 시간이 경과했습니다. 지금 도착할 지연 결과는 없습니다."
            },
        )
        render()
    }

    /** Applies one authored catalog event and names whether the current draft was hit. */
    private fun applySyntheticCatalogEvent(event: CatalogEvent) {
        panel = null
        editingFieldId = null
        val affected = surface.lines().count { it.menuValueToken == event.replacesValue }
        val outcome = try {
            surface.applyCatalogEvent(event.eventToken)
        } catch (error: Exception) {
            Toast.makeText(this, "처리하지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
            render()
            return
        }
        lastDecision = describe(outcome)
        val subject = catalog.valueLabel(event.replacesValue)
        chat += ChatLine(
            "에이전트:",
            if (affected > 0) {
                "$subject 관련 합성 재고·가격 변화를 반영했습니다. 영향받은 항목만 다시 확인하고 나머지 초안은 유지했습니다."
            } else {
                "$subject 관련 합성 재고·가격 변화를 반영했습니다. 현재 주문서에는 해당 항목이 없어 초안은 그대로입니다."
            },
        )
        render()
    }

    /** The synthetic network state the decision path reads. */
    private fun networkPanel(): View {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(
            Ui.menuGroup(this, "이 기기의 실제 연결 — ${readDeviceLink(this).label} · 표시 전용"),
        )
        body.addView(
            Ui.menuGroup(this, "에이전트는 아래 합성 상태로만 판단합니다. 실제 연결과 별개입니다."),
        )
        listOf(
            "ONLINE" to "현재 메뉴정보 확인 가능",
            "DELAYED" to "최신 메뉴정보 지연 — 질문이 먼저, 없으면 대기",
            "OFFLINE" to "cache가 있으면 대기, 없으면 중단",
            "UNKNOWN" to "최신 여부 미확인",
        ).forEach { (name, detail) ->
            body.addView(
                Ui.menuItem(this, name, detail) {
                    closePanel()
                    act { it.setNetwork(name) }
                },
            )
        }
        return Ui.sheet(this, "network 상태", body, null) { openPanel(Panel.MENU) }
    }

    /**
     * The values this restaurant offers for one draft row, ready to tap. Empty
     * when the row is not a choice the user makes here, such as the total.
     */
    private fun editChoices(
        field: DraftField,
        restaurant: RestaurantDefinition?,
    ): List<Ui.Chip> {
        if (restaurant == null) return emptyList()
        if (field.slotId == AsprEngine.SLOT_TOTAL) return emptyList()
        val slot = catalog.slotOfFieldSlotId(field.slotId)
            ?: catalog.baseSlotOfLineSlotId(field.slotId)
            ?: return emptyList()
        return catalog.valuesFor(restaurant, slot.scopeToken)
            .filter { it.inStock }
            .map { option ->
                Ui.Chip(
                    label = option.label,
                    sub = if (option.priceDelta > 0) {
                        "+${pricing.formatAmount(option.priceDelta)}"
                    } else {
                        ""
                    },
                    selected = option.token == field.value,
                ) {
                    editingFieldId = null
                    answerField(field, option.token)
                }
            }
    }

    // -------------------------------------------------------------- helpers

    private fun act(block: (ProductSurface) -> StepOutcome) {
        val outcome = try {
            block(surface)
        } catch (error: Exception) {
            Toast.makeText(this, "처리하지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
            return
        }
        lastDecision = describe(outcome)
        render()
    }

    /** Same as [act] for actions whose step outcome carries nothing to report. */
    private fun actQuiet(block: (ProductSurface) -> Unit) {
        try {
            block(surface)
        } catch (error: Exception) {
            Toast.makeText(this, "처리하지 못했습니다: ${error.message}", Toast.LENGTH_LONG).show()
            return
        }
        render()
    }

    private fun describe(outcome: StepOutcome): String {
        val result = outcome.result
        return "${humanDecision(result.optString("decision_state"))} " +
            "(${result.optString("decision_state")}, ${result.optString("operation")})"
    }

    private fun decisionSentence(outcome: StepOutcome): String =
        when (outcome.result.optString("decision_state")) {
            "ACT" -> "초안을 확인해 가상 주문으로 기록했습니다."
            "ASK" -> "확인이 필요한 항목이 남아 있습니다."
            "WAIT" -> "최신 메뉴정보를 받지 못해 기다리는 중입니다. 초안은 그대로 있습니다."
            "ABSTAIN" -> "조건을 모두 만족하는 안이 없어 진행을 멈췄습니다."
            "PENDING" -> "아직 확정하지 않았습니다."
            "CONFIRMED_COMPLETE" -> "이미 처리한 요청입니다. 중복으로 반영하지 않았습니다."
            "FAILED" -> "복구가 필요합니다."
            else -> "상태를 갱신했습니다."
        }

    private fun humanDecision(decision: String): String = when (decision) {
        "ACT" -> "초안 확정 — 가상 주문 기록"
        "ASK" -> "확인 필요 — 질문"
        "WAIT" -> "대기 — 최신 메뉴정보 필요"
        "ABSTAIN" -> "중단 — 안전한 대안 없음"
        "PENDING" -> "진행 중 — 아직 확정 아님"
        "CONFIRMED_COMPLETE" -> "이미 처리된 요청 (중복 반영 없음)"
        "FAILED" -> "복구 필요"
        else -> "상태 변경"
    }

    private fun networkLabel(state: ProductionState): String = when (state.network.name) {
        "ONLINE" -> "ONLINE — 현재 메뉴정보 확인 가능"
        "DELAYED" -> "DELAYED — 최신 메뉴정보 지연"
        "OFFLINE" -> "OFFLINE — commit 보류"
        else -> "UNKNOWN — 최신 여부 미확인"
    }

    private fun armLabel(): String = when (Production.selectedArm(this).namespace) {
        "claim-off" -> "claim-off (최신 값만 참고, 새 session에서 재확인)"
        else -> "full (ASPR 켜짐)"
    }

    private companion object {
        // A thread the user scrolls, not a status box, so it keeps more turns.
        const val MAX_CHAT_LINES = 40
    }
}
